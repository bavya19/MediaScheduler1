﻿namespace enumerableType
{
    internal class IsAssignableFrom
    {
    }
}