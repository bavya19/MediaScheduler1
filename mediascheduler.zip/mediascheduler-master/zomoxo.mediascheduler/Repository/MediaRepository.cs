using System;
using System.Collections.Generic;
using zomoxo.mediascheduler.Models;

namespace zomoxo.mediascheduler.Repository
{
    public class MediaRepository : IMediaRepository
    {
        public DateTime FromDate { get; private set; }
        public DateTime ToDate { get; private set; }

        /// <inheritdoc />
        public GeneratedScheduleResponse GenerateSchedule(GenerateScheduleRequest request)
        {
            
            request.FromDate = Convert.ToDateTime(FromDate);
        request.ToDate = Convert.ToDateTime(ToDate);
            GeneratedScheduleResponse Response = new GeneratedScheduleResponse();
            TimeSpan ts = request.ToDate - request.FromDate;
            string msg = String.Format("Elapsed Time : " + ts.TotalMinutes);
            //TimeSpan ts = request.ToDate - request.FromDate;
        
       //ScheduledMedia scheduled = new ScheduledMedia();
        Response.ScheduledMedia = new List<ScheduledMedia>();
        
        int ttime = Convert.ToInt32(ts.TotalMinutes);
            Console.WriteLine(msg);
            throw new System.NotImplementedException();
        }
               //Console.WriteLine("**************************** End of Sequence/Schedule *********************");
            }
            //Implement scheduling
            //
        }
    